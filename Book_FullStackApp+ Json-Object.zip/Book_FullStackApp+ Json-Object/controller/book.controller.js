const fs = require('fs');
let books ;
let fileName = 'C:\\Users\\deepd\\Documents\\Training\\Book_FullStackApp+ Json-Object\\models\\books.json';
fs.readFile(fileName,(err,data)=>{
    if(err) throw err;
   let booksData = JSON.parse(data);
    books = booksData.books;
})

        const getallbooks = (req,res) => {
            res.send(books);
        }    

        const getbookById = (req,res) => {
            const id = req.params.id;
            let book = books.find(book => book.id === parseInt(id))
            res.send(book);
        }

        const createBook = (req,res) => {
            // console.log(res);
            const book = {
                id: books.length + 1,
                title: req.body.title,
                category: req.body.category,
                description: req.body.description,
                purchasecount: req.body.purchasecount,
                author: req.body.author,
            }
            books.push(book);
            fs.writeFile('C:\\Users\\deepd\\Documents\\Training\\Book_FullStackApp+ Json-Object\\models\\books.json', JSON.stringify({books:books}),(err) => {
if (err) throw err;
            });
            res.send(book);
        }

        const updatebookById = (req,res) => {
            const id = req.params.id;
            const book = books.find(book => book.id === parseInt(id))   
            book.title = req.body.title;
            book.category= req.body.category;
            book.description = req.body.description;
            book.purchasecount = req.body.purchasecount;
            book.author = req.body.author;
        fs.writeFile(fileName, JSON.stringify({books:books}), (err) => {
        if (err) throw err;
        });
        res.send(book);
    }
        const deletebookById = (req, res) => {
          const id = req.params.id;
          books = books.filter(book => book.id !== parseInt(id));
          fs.writeFile(
            "C:\\Users\\deepd\\Documents\\Training\\Book_FullStackApp+ Json-Object\\models\\books.json",
            JSON.stringify({ books: books }),
            (err) => {
              if (err) throw err;
            }
          );
          res.send(books);
        };


        module.exports = {getallbooks, getbookById, createBook, updatebookById, deletebookById}