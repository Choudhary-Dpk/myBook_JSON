const express = require('express');
const bookRoutes = express.Router();
const {getallbooks, getbookById, createBook, updatebookById, deletebookById} = require('../controller/book.controller');


bookRoutes.get('/',getallbooks);

bookRoutes.get('/:id',getbookById); 

bookRoutes.post('/',createBook); 

bookRoutes.patch('/:id',updatebookById);

bookRoutes.delete('/:id',deletebookById);

module.exports = {bookRoutes};
