const express = require('express')
const app = express()

const mysql = require('mysql')

const {bookRoutes} = require('./routes/book.route')
const fs = require('fs')


app.use(express.json());
app.use('/book',bookRoutes) 
app.get('/', function (req, res) { 
  res.sendFile('C:\\Users\\deepd\\Documents\\Training\\Book_FullStackApp+ Json-Object\\View\\Book.html')
})

app.listen(3001, function(){
  console.log("Book app listening on the port 3001.");
})